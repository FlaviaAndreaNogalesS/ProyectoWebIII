export interface LoginResponse {
    refresh: string;
    access: string;
}
