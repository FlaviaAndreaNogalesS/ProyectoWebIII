export const URLS = {
  LOGIN: "/login",
  REGISTER: "/register",
  HOME: "/",
  USUARIOS_ADMIN: "/admin/usuarios"

};
